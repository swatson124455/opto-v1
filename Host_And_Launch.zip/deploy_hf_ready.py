"""Automated deployment to Hugging Face Spaces.

Usage:
    double-click host.bat to deploy your app to Hugging Face and get the link.
"""
import os
from huggingface_hub import HfApi, Repository, create_repo

HF_TOKEN = "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"
REPO_NAME = "fantasy-draft-engine"

def main():
    api = HfApi()
    user_info = api.whoami(token=HF_TOKEN)
    username = user_info["name"]
    space_id = f"{username}/{REPO_NAME}"
    print(f"Deploying to https://huggingface.co/spaces/{space_id}")

    create_repo(
        repo_id=space_id,
        token=HF_TOKEN,
        repo_type="space",
        space_sdk="streamlit",
        exist_ok=True
    )

    local_dir = "hf_space"
    if os.path.isdir(local_dir):
        import shutil
        shutil.rmtree(local_dir)
    os.makedirs(local_dir, exist_ok=True)

    with open(f"{local_dir}/app.py", "w") as f:
        f.write("""import streamlit as st
import pandas as pd

st.set_page_config(page_title="Fantasy Football Draft Engine", layout="wide")
st.title("Fantasy Football Draft Engine")

uploaded = st.file_uploader("📥 Upload your projections CSV", type="csv")
if uploaded:
    df = pd.read_csv(uploaded)
    st.write("### Preview of your data")
    st.dataframe(df)
    if st.button("🚀 Run Optimizer"):
        st.write("Running optimizer on your data…")
else:
    st.info("Please upload a projections CSV to begin.")
""")
    with open(f"{local_dir}/requirements.txt", "w") as f:
        f.write("""streamlit
pandas
numpy
scikit-learn
pulp
""")
    repo_url = f"https://huggingface.co/spaces/{space_id}"
    repo = Repository(local_dir=local_dir, clone_from=repo_url, use_auth_token=HF_TOKEN)
    repo.push_to_hub(commit_message="Deploy app", blocking=True)
    print(f"✅ Live at https://huggingface.co/spaces/{space_id}")

if __name__ == "__main__":
    main()
